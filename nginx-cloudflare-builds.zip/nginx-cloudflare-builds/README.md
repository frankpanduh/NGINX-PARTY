# NGINX-PARTY

Community build of **Nginx with QUIC/HTTP3, Brotli, AVIF/WebP, and media streaming extras** — optimized for Cloudflare + modern web.

## Features
- QUIC + HTTP/3
- Brotli compression
- TLS 1.3 hardened
- AVIF/WebP image serving
- Optional RTMP/HLS livestream support
- Sample configs for WAF & caching

## Installation
Grab the latest `.deb` from Releases.

```bash
sudo dpkg -i nginx-quic-custom_*.deb
```

## Why?
Ubuntu/Debian packages often lag behind with HTTP/3/QUIC.  
This repo provides **automated builds** so you can stay secure & media-ready without compiling by hand. Testing this out to help folks who want features now. 
